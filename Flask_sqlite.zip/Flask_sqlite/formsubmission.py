from flask_wtf import Form 
from flask_wtf import FlaskForm
from wtforms import StringField,TextAreaField,IntegerField,SubmitField,EmailField,PasswordField
from wtforms.validators import ValidationError,DataRequired 

class RegistrationForm(FlaskForm):
    name = StringField(label="Username",validators=[DataRequired()] ) 
    email = EmailField(label="Email",validators=[DataRequired()]) 
    password = PasswordField(label="Password",validators=[DataRequired()]) 
    submit = SubmitField("Send") 