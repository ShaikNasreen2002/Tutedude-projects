import sqlite3 

conn = sqlite3.connect('user_table.db') 
c = conn.cursor() 

stmt = """CREATE TABLE IF NOT EXISTS adduser(name TEXT, password TEXT, email TEXT)""" 
c.execute(stmt) 
conn.commit()  