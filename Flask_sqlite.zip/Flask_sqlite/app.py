from flask import Flask, render_template, request, flash, redirect, url_for
from flask_wtf import FlaskForm
from formsubmission import RegistrationForm 
import sqlite3 

app = Flask(__name__,template_folder="templates") 
app.secret_key = 'your_secret_key' 

authenticated = False

@app.route('/') 
def index():
    return render_template('index.html')  

@app.route('/register',methods=['POST','GET']) 
def register():
    obj = RegistrationForm()
    conn = sqlite3.connect('user_table.db') 
    c = conn.cursor() 
    if request.method=='POST':
        #if(request.form["name"]!="" and request.form["password"]!="" and request.form["email"]!=""):
        name = request.form["name"] 
        password = request.form["password"] 
        email = request.form["email"] 
        '''stmt = f"SELECT * FROM adduser WHERE name='{name}' and password='{password}' and email='{email}';" 
            c.execute(stmt) 
            data = c.fetchone()'''
        stmt = "SELECT * FROM adduser WHERE name=? and password=? and email=?;"
        data = c.execute(stmt, (name, password, email)).fetchone()
        if data is not None:
            authenticated = True
            print("Already you are registered") 
            return redirect(url_for('register'))
        else:
            if not data:
                c.execute("INSERT INTO adduser(name,password,email) VALUES(?,?,?)",(name,password,email)) 
                conn.commit()
                conn.close()
                return redirect(url_for('login'))
                    
    elif request.method=='GET':
        return render_template('register.html',form=obj)  #,form=obj

@app.route('/login',methods=['POST','GET'])
def login():
    obj = RegistrationForm()
    conn = sqlite3.connect('user_table.db') 
    c = conn.cursor() 
    if request.method=='POST':
        name = request.form["name"] 
        password = request.form["password"]  
        stmt = f"SELECT * FROM adduser WHERE name='{name}' and password='{password}';"  # and email='{email}
        c.execute(stmt) 
        if not c.fetchone():
            c.execute("INSERT INTO adduser(name,password,email) VALUES(?,?,?)",(name,password))  #,email
            #conn.commit()
            #conn.close()
            return render_template('login.html')
        else:
            return redirect(url_for('dashboard')) 
    elif request.method=='GET':
        return render_template('login.html',form=obj)

@app.route('/logout')
def logout():
    global authenticated
    # Log the user out by setting authentication flag to False
    authenticated = False
    return redirect(url_for('index'))

@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

if __name__=='__main__':
    app.run(debug=True) 