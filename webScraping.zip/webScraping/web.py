import sys
import requests
import urllib.request, urllib.parse, urllib.error
import requests
from bs4 import BeautifulSoup
class Pricetracer:
    def __init__(self, url) -> None:
        self.url = url
        self.user_agent = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0 Pro; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
        #self.user_agent = {'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'}
        self.response = requests.get(url = self.url, headers=self.user_agent).text
        self.soup = BeautifulSoup(self.response,"lxml") 
    
    def product_title(self):
        title = self.soup.find("span", {"id":"productTitle"})
        #print(title)
        if title is not None:
            return title.text.strip(" ")
        return "No title"
    def product_price(self): 
        #<span class="a-price-whole">999</span>
        price = self.soup.find("span", {"class":"a-price-whole"})
        #print(title)
        if price is not None:
            return price.text

device = Pricetracer("https://www.amazon.in/Brownverse-Women-Black-Embroidered-Cotton/dp/B0C951H6W2/ref=sr_1_1_sspa?crid=3DT6S7JW6C8WF&keywords=kurta%2Bset%2Bfor%2Bwomen&qid=1701265934&sprefix=kurta%2Caps%2C245&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&th=1&psc=1")
print(device.product_title())
print(device.product_price()) 
laptop = Pricetracer("https://www.amazon.in/2022-Apple-MacBook-Laptop-chip/dp/B0B3BLY13H/ref=sr_1_1_sspa?crid=3DHI03B4EZ2IA&keywords=apple+laptop&qid=1701269626&sprefix=apple+laptop%2Caps%2C242&sr=8-1-spons&sp_csd=d2lkZ2V0TmFtZT1zcF9hdGY&psc=1") 
print(laptop.product_title())
print(laptop.product_price()) 