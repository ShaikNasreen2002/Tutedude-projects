import sqlite3
from django.db import models

# Create your models here.

class UserProfile(models.Model):
    firstname = models.CharField(max_length=50)
    lastname = models.CharField(max_length=50)
    username = models.CharField(max_length=50)
    email = models.EmailField()
    password = models.CharField(max_length=50)  # In a real-world scenario, use a password hash field

    def __str__(self):
        return self.username
