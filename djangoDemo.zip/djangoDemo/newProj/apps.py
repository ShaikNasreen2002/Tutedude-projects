from django.apps import AppConfig


class NewprojConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'newProj'
